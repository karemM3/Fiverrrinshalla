export const Overlay = () => {
    return (
        <div
            className="opacity-100 group-hover:opacity-30 bg-black h-full w-full trasition-opacity"
        />
    );
};
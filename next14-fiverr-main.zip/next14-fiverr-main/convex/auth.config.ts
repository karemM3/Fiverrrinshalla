export default {
    providers: [
      {
        domain: "https://direct-gopher-17.clerk.accounts.dev/",
        applicationID: "convex",
      },
    ]
  };